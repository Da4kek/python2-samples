def f(): "maybe a docstring"
