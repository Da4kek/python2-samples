#!/usr/bin/env python
# To use:
#       python setup.py install
#
import os, sys, string, re
from glob import glob

# Check for an advanced enough Distutils.
try:
    import distutils
    from distutils.command.install import install
    from distutils.core import setup, Extension
except:
    raise SystemExit, "Distutils problem, see Numeric README."

headers = glob (os.path.join ("Include","*.h"))
setup (name = "Numeric",
       packages = [''],
       package_dir = {'': 'Lib'},
       extra_path = 'Numeric',
       include_dirs = ['Include'],
       headers = headers,
       ext_modules = [ Extension('ranlib',
                                ['Src/ranlibmodule.c',
                                 'Src/ranlib.c',
                                 'Src/com.c',
                                 'Src/linpack.c']),
                     ]
       )


