# sample of indexing behavior
from MA import *

a = array([1,2,3,4,5], Float, mask=[0,1,0,0,0])
print a
print "------"
for i in range(len(a)):
    print i, a[i]
print "------"
a.set_fill_value(masked)
for x in a:
    print x
print "------"
print "filled with masked", filled(a, masked)
