import os, string
try:
    from distutils.core import setup
except:
    raise SystemExit, "Distutils problem, see Numeric README."

s = os.path.join('Lib','MA_version.py')
execfile(s)
setup (name = "MA",
       version=version,
       author="Paul F. Dubois",
       description = "Masked Array facility",
       url = "http://sourceforge.net/projects/numpy",
       packages = ['MA'],
       package_dir = {'MA': 'Lib'},
      )
print "MA Version", version
    
