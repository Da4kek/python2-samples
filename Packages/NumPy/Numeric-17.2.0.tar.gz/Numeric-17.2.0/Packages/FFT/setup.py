import os, sys, string, re
from glob import glob

# Check for an advanced enough Distutils.
try:
    import distutils
    from distutils.core import setup, Extension
except:
    raise SystemExit, "Distutils problem, see Numeric README."

setup (name = "FFTPACK",
       version = "1.0",
       maintainer = "Numerical Python Developers",
       maintainer_email = "numpy-discussion@lists.sourceforge.net",
       description = "Fast Fourier Transforms",
       url = "http://numpy.sourceforge.net",

       packages = ['FFT'],
       package_dir = {'FFT': 'Lib'},
       include_dirs = ['Include'],
       ext_modules = [ Extension('FFT.fftpack',
                                ['Src/fftpackmodule.c',
                                 'Src/fftpack.c']),
                     ]
       )
