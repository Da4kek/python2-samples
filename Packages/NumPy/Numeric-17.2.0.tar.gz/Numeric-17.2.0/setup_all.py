#!/usr/bin/env python
import string, os, sys
cwd = os.getcwd()
packages=['RNG', 'LALITE', 'RANLIB', 'MA', 'FFT']
execfile('setup.py')
for p in packages:
   d = os.path.join(cwd, 'Packages', p)
   os.chdir(d)
   print "Working on", d, "(", os.getcwd(), ")"
   os.system(sys.executable+' setup.py '+string.join(sys.argv[1:],' '))
