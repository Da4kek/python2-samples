from Numeric import *
def close(x,y): 
    return abs(x-y) < 1.e5

x=arange(5)
put (x, [1,4],[10,40])
assert allclose(x, [0,10,2,3,40])

x=arange(5) * 1.0
put (x, [1,4],[10.,40.])
assert allclose(x, [0.,10.,2.,3.,40.])

x=arange(5) 
put (x, [1,4],[10])
assert allclose(x, [0,10,2,3,10])

x=arange(5) 
put (x, [1,4],10)
assert allclose(x, [0,10,2,3,10])

x=arange(5) 
put (x, [0,1,2,3], [10,20])
assert allclose(x, [10,20,10,20,4])

x=arange(5) 
put (x, [[0,1],[2,3]], [10,20])
assert allclose(x, [10,20,10,20,4])

x = arange(5).astype(Float32)
put (x, [1,4],[10.,40.])
assert allclose(x, [0,10,2,3,40])

x=arange(6)*1.0
x.shape=(2,3)
put(x, [1,4],[10,40])
assert allclose(x, [[0,10,2],[3,40,5]])

x=arange(5)
putmask (x, [1,0,1,0,1], [-1,10,20,30,40]) 
assert allclose(x, [-1,1,20,3,40])

x=arange(10)
putmask(x, ones(10), 5)
assert allclose(x, 5*ones(10))

x=arange(10)*1.0
x=x.astype(Float32)
putmask(x, [0,0,1,0,0,0,0,0,0,1], 3.0)
assert allclose(x, [0.,1.,3.,3.,4.,5.,6.,7.,8.,3.])

print "Puttest: all tests passed."
