#!/usr/bin/env python
# To use:
#       python setup.py install
#
import os, sys, string, re
from glob import glob

try:
    import distutils
    from distutils.command.install import install
    from distutils.core import setup, Extension
except:
    raise SystemExit, "Distutils problem, see Numeric README."

headers = glob (os.path.join ("Include","*.h"))

# The version is set in Lib/numeric_version.py
execfile(os.path.join('Lib','numeric_version.py'))

setup (name = "Numeric",
       version = version,
       maintainer = "Numerical Python Developers",
       maintainer_email = "numpy-developers@lists.sourceforge.net",
       description = "Numerical Extension to Python",
       url = "http://numpy.sourceforge.net",

       packages = [''],
       package_dir = {'': 'Lib'},
       extra_path = 'Numeric',
       include_dirs = ['Include'],
       headers = headers,
       ext_modules = [Extension('_numpy',
                                ['Src/_numpymodule.c',
                                 'Src/arrayobject.c',
                                 'Src/ufuncobject.c']),
                      Extension('multiarray', ['Src/multiarraymodule.c']),
                      Extension('umath', ['Src/umathmodule.c']),
                      Extension('arrayfns',
                                ['Src/arrayfnsmodule.c'])
                     ]
       )
print "Numeric Version", version

